#version 400 compatibility
/*
!! DO NOT REMOVE !!
This code is from Chocapic13' shaders
Read the terms of modification and sharing before changing something below please !
!! DO NOT REMOVE !!
*/

#define WAVING_LEAVES   // leaves wave in the wind
#define WAVING_VINES    // vines wave in the wind
#define WAVING_GRASS    // grass, crops and flowers wave
#define WAVING_LILYPAD  // lilypads and other watery plants wave

#define GRASS 10031
#define CROPS 10059
#define TALLPLANTS_LOWER 10175
#define TALLPLANTS_UPPER 10176
#define LEAVES 10018
#define VINES 10106
#define LILYPAD 10111
#define FIRE 10051
#define LAVA 10010
#define WATER 10008
#define REFLECTIVE 10079
#define NOT_OCCLUSIVE 10030
#define DEAD_PLANT 10032
#define EMISSIVE 10089

out vec4 color;
out vec4 texcoord;

out vec4 normal;

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float sunAngle;
int worldTime = int(24000.0 * sunAngle);
uniform float frameTimeCounter;
uniform float rainStrength;
const float PI48 = 150.796447372;
float pi2wt = PI48 * frameTimeCounter;

vec3 calcWave(in vec3 pos, in float fm, in float mm, in float ma, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5) {
    float magnitude = sin(dot(vec4(pi2wt * fm, pos.x, pos.z, pos.y), vec4(0.5))) * mm + ma;
    vec3 d012 = sin(pi2wt * vec3(f0, f1, f2));
    vec3 ret = sin(pi2wt * vec3(f3, f4, f5) + vec3(d012.x + d012.y, d012.y + d012.z, d012.z + d012.x) - pos) * magnitude;

    return ret;
}

vec3 calcMove(in vec3 pos, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5, in vec3 amp1, in vec3 amp2) {
    vec3 move1 = calcWave(pos, 0.0054, 0.0400, 0.0400, 0.0127, 0.0089, 0.0114, 0.0063, 0.0224, 0.0015) * amp1;
    vec3 move2 = calcWave(pos + move1, 0.07, 0.0400, 0.0400, f0, f1, f2, f3, f4, f5) * amp2;
    return move1 + move2;
}

//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {
    normal.xyz = gl_NormalMatrix * gl_Normal;
    texcoord = vec4((gl_MultiTexCoord0).xy, (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy);

    bool istopv = gl_MultiTexCoord0.t < mc_midTexCoord.t;

    //optimisation to get only one comparison to do per waving move
    //(a-x)*(b-x)*(c-x)*(d-x)
    bool wavy1 = false;
    bool wavy2 = false;
    bool emissive = false;
    color = gl_Color;
    normal.a = 0.02;

    switch (int(mc_Entity.x)) {
#ifdef WAVING_GRASS
        case GRASS:
            wavy1 = true;
            break;
        case CROPS:
            wavy1 = true;
            break;
        case TALLPLANTS_LOWER:
            wavy1 = true;
            break;
        case TALLPLANTS_UPPER:
            wavy2 = true;
            break;
#else
        case GRASS:
            normal.a = 0.7;
            break;
        case CROPS:
            normal.a = 0.7;
            break;
        case TALLPLANTS_LOWER:
            normal.a = 0.7;
            break;
        case TALLPLANTS_UPPER:
            normal.a = 0.7;
            break;
#endif
#ifdef WAVING_LEAVES
        case LEAVES:
            wavy2 = true;
            break;
#endif
        case VINES:
#ifdef WAVING_VINES
            wavy2 = true;
#endif
            normal.a = 0.7;
            break;
        case LILYPAD:
#ifdef WAVING_LILYPAD
            wavy2 = true;
#endif
            normal.a = 0.7;
            break;
        case FIRE:
            emissive = true;
            break;
        case LAVA:
            emissive = true;
            break;
        case NOT_OCCLUSIVE:
            normal.a = 0.7;
            break;
#ifdef WAVING_GRASS
        case DEAD_PLANT:
            wavy1 = true;
            break;
#endif
        case EMISSIVE:
            emissive = true;
            break;
    }

    if (emissive) {
        color = vec4(1.0);
        normal.a = 0.6;
    }

    gl_Position = ftransform();
    if ((istopv && wavy1) || wavy2) {
        vec4 position = gl_ModelViewMatrix * gl_Vertex;
        position = gbufferModelViewInverse * position;
        vec3 worldpos = position.xyz + cameraPosition;
        position.xyz += calcMove(worldpos.xyz, 0.0040, 0.0064, 0.0043, 0.0035, 0.0037, 0.0041, vec3(1.0, 0.2, 1.0), vec3(0.5, 0.1, 0.5)) * 1.4;
        position = gbufferModelView * position;
        gl_Position = gl_ProjectionMatrix * position;
    }

    normal.a = (wavy1 || wavy2) ? 0.7 : normal.a;

    color.rgb *= vec3(1.0 + float(wavy1 || wavy2) * 0.1);

    /*--------------------------------*/
}
