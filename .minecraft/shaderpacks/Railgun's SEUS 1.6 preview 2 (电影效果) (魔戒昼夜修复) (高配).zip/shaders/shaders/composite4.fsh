#version 120

/* DRAWBUFFERS:2 */

const bool gaux2MipmapEnabled = true;

uniform sampler2D gcolor;
uniform sampler2D gdepth;
uniform sampler2D gdepthtex;
uniform sampler2D gnormal;
uniform sampler2D gaux2;
uniform sampler2D gaux1;
uniform sampler2D composite;
uniform sampler2D noisetex;
        
		
uniform float aspectRatio;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;

uniform vec3 sunPosition;
uniform vec3 moonPosition;

uniform int   isEyeInWater;
uniform float sunAngle;
int worldTime = int(24000.0 * sunAngle);

uniform mat4 gbufferProjection;
uniform float frameTimeCounter;
varying float timeSunrise;
varying float timeNoon;
varying float timeSunset;
varying float timeMidnight;

varying vec4 texcoord;

float timeDay = 1.0 - timeMidnight;
float timeNoonNight = timeMidnight + timeNoon;
float timeSunriseSunset = 1.0 - timeNoonNight;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
float dynamicWeather() {
	
	float value = 1.0;
		  value *= abs(sin(frameTimeCounter * 0.01 * 1.2));
		  value *= abs(cos(frameTimeCounter * 0.01 * 0.5));
		  value *= abs(sin(frameTimeCounter * 0.01 * 2.0));
	
	// Raining.
	value = mix(value, 1.0, rainStrength);
		  
	return value;
	
}	

#define ORB_FLARE_COUNT	6
#define DISTORTION_BARREL	1.75
vec2 iChannelResolution = vec2(viewWidth, viewHeight);

vec4 noise(float p){return texture2D(noisetex,vec2(p/iChannelResolution.x,.0));}
vec4 noise(vec2 p){return texture2D(noisetex,p/iChannelResolution.xy);}

float t = frameTimeCounter;

vec2 GetDistOffset(vec2 uv, vec2 pxoffset)
{
    vec2 tocenter = uv.xy;
    vec3 prep = normalize(vec3(tocenter.y, -tocenter.x, 0.0));
    
    float angle = length(tocenter.xy)*2.221*DISTORTION_BARREL;
    vec3 oldoffset = vec3(pxoffset,0.0);
    
    vec3 rotated = oldoffset * cos(angle) + cross(prep, oldoffset) * sin(angle) + prep * dot(prep, oldoffset) * (1.0-cos(angle));
    
    return rotated.xy;
}

vec3 flare(vec2 uv, vec2 pos, float dist, float size)
{
    pos = GetDistOffset(uv, pos);
    float r = max(0.01-pow(length(uv+(dist-.05)*pos),2.4)*(1./(size*2.)),.0)*6.0;
	float g = max(0.01-pow(length(uv+ dist     *pos),2.4)*(1./(size*2.)),.0)*6.0;
	float b = max(0.01-pow(length(uv+(dist+.05)*pos),2.4)*(1./(size*2.)),.0)*6.0;
    
    return vec3(r,g,b);
}

vec3 flare(vec2 uv, vec2 pos, float dist, float size, vec3 color)
{
    return flare(uv, pos, dist, size)*color;
}

vec3 orb(vec2 uv, vec2 pos, float dist, float size)
{
    vec3 c = vec3(0.0);
   
    for(int i=0; i<ORB_FLARE_COUNT; i++)
    {
        float j = float(i+1);
        float offset = j/(j+1.);
        float colOffset = j/float(ORB_FLARE_COUNT*2);
        
        c += flare(uv,pos,dist+offset, size/(j+.1), vec3(1.0-colOffset, 1.0, 0.5+colOffset));
    }
    
    c += flare(uv,pos,dist+.5, 4.0*size, vec3(1.0))*4.0;
    
    return c/4.0;
}

vec3 orb(vec2 uv, vec2 pos, float dist, float size, vec3 color)
{
    return orb(uv,pos,dist,size)*color;
}

vec3 ring(vec2 uv, vec2 pos, float dist)
{
    pos = GetDistOffset(uv, pos);
    vec2 uvd = uv*(length(uv));
    
    float r = max(1.0/(1.0+32.0*pow(length(uvd+(dist-.05)*pos),2.0)),.0)*00.25;
	float g = max(1.0/(1.0+32.0*pow(length(uvd+ dist     *pos),2.0)),.0)*00.23;
	float b = max(1.0/(1.0+32.0*pow(length(uvd+(dist+.05)*pos),2.0)),.0)*00.21;
    
    return vec3(r,g,b);
}

vec3 lens(vec2 uv,vec2 pos, float brightness, float size)
{
   
    vec3 c;
         c += flare(uv,pos,-3.,3.*size);
         c += flare(uv,pos, -1.,size)*3.;
         c += flare(uv,pos, .5,.8*size);
         c += flare(uv,pos,-.4,.8*size);
    
         c += orb(uv,pos, 0., .5*size);
    
         c += ring(uv,pos,-1.)*.5*size;
         c += ring(uv,pos, 1.)*.5*size;
    
    return c*brightness;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
float distratio(vec2 pos, vec2 pos2, float ratio) {
    float xvect = pos.x*ratio-pos2.x*ratio;
    float yvect = pos.y-pos2.y;
    return sqrt(xvect*xvect + yvect*yvect);
}

float Circulardist(in float lensDist, float size , float shapes) {
     
	vec4 tpos = vec4(sunPosition,1.0)*gbufferProjection;
		 tpos = vec4(tpos.xyz/tpos.w,1.0);
	vec2 lightPos = tpos.xy/tpos.z*lensDist;
		 lightPos = (lightPos + 1.0f)/2.0f;
     
	return 1.0-pow(min(distratio(vec2(lightPos.x,lightPos.y),vec2(texcoord.x,texcoord.y),aspectRatio * shapes),size)/size,4.5);
}

vec2 rand(vec2 coord){
    return vec2(fract(sin(dot(coord.xy ,vec2(12.9898,78.233))) * 43758.5453), fract(cos(dot(coord.yx ,vec2(8.64947,45.097))) * 43758.5453)) * 2.0 -1.0;
}

vec2 texel = vec2(1.0/viewWidth,1.0/viewHeight);
	
#define deg2rad 3.14159 / 180.
float hex() {                        

		vec2 uv = texcoord.xy;
		float size = 1;
		size *= (viewHeight + viewWidth) / 1920.0;
		
		float r = 0.0;
		
		vec2 v = (uv / texel);
			
		vec2 topBottomEdge = vec2(0., 1.);
		vec2 leftEdges = vec2(cos(30.*deg2rad), sin(30.*deg2rad));
		vec2 rightEdges = vec2(cos(30.*deg2rad), sin(30.*deg2rad));

		float dot1 = dot(abs(v), topBottomEdge);
		float dot2 = dot(abs(v), leftEdges);
		float dot3 = dot(abs(v), rightEdges);

		float dotMax = max(max((dot1), (dot2)), (dot3));
		
		return max(0.0, mix(0.0, mix(1.0, 1.0, floor(size - dotMax*1.1 + 0.99 )), floor(size - dotMax + 0.99 ))) * 0.1;
}	

float randomDots(vec2 coord) {

	vec2 aspectcorrect = vec2(aspectRatio, 1.0);

	vec2 g = floor(coord * aspectcorrect);
	vec2 f = fract(coord * aspectcorrect) * 2.0 - 1.0;
	vec2 r = rand(g) * .5;

	return length(f + r);
}

float GetLenstex(vec2 coord) {

	float dirtylens = 0.0;

	      dirtylens += 1.-randomDots(coord * .2);
	      dirtylens += 1.-randomDots(coord * .4);
	      dirtylens += 1.-randomDots(coord * .3);
		  
		  dirtylens += 1.-smoothstep(0.1, 0.3, randomDots(coord * 4.))  * .7;
	      dirtylens += 1.-smoothstep(0.1, 0.3, randomDots(coord * 8.))  * .6;
	      dirtylens += 1.-smoothstep(0.1, 0.3, randomDots(coord * 10.)) * .5;
		  
		  dirtylens += 1.-smoothstep(0.1, 0.3, randomDots(coord * 12.)) * .3;
	      dirtylens += 1.-smoothstep(0.1, 0.3, randomDots(coord * 20.)) * .4;
	      dirtylens += 1.-smoothstep(0.1, 0.3, randomDots(coord * 30.)) * .5;

	return dirtylens;
}

float smoothCircleDist (in float lensDist) {

		vec4 tpos = vec4(sunPosition,1.0)*gbufferProjection;
			 tpos = vec4(tpos.xyz/tpos.w,1.0);
		vec2 lightPos = tpos.xy/tpos.z*lensDist;
			 lightPos = (lightPos + 1.0f)/2.0f;
			 
		return distratio(lightPos.xy, texcoord.xy, aspectRatio);	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main() {
	vec4 color = texture2D(gnormal, texcoord.xy);
		 color.a = 1.0;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	vec3 sunPos = sunPosition;
	float pw = 1.0/ viewWidth;
    float ph = 1.0/ viewHeight;
	vec4 tpos = vec4(sunPosition,1.0)*gbufferProjection;
         tpos = vec4(tpos.xyz/tpos.w,1.0);
		 
    vec2 lightPos = tpos.xy/tpos.z;
		 lightPos = (lightPos + 1.0f)/2.0f;

    float distof = min(min(1.0-lightPos.x,lightPos.x),min(1.0-lightPos.y,lightPos.y));
	float fading = clamp(1.0-step(distof,0.1)+pow(distof*10.0,5.0),0.0,1.0);		 
	
	float time = float(worldTime);
	float transition_fading = 1.0-(clamp((time-12000.0)/500.0,0.0,1.0)-clamp((time-13000.0)/500.0,0.0,1.0) + clamp((time-22500.0)/100.0,0.0,1.0)-clamp((time-23300.0)/200.0,0.0,1.0));	 
	
	float sunvisibility;
	
	for (int i = 0; i < 1;i++) {
			for (int j = 0; j < 1 ;j++) {
          sunvisibility = min(float(texture2D(gdepth,lightPos + vec2(pw*(i-5.0),ph*(j-5.0))).r == 0), 1.0) * fading * transition_fading;
		}
	}	  
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

	float lensBrightness = 0.0;
	float lensExpDT = 1.0;

	      lensBrightness = 1.0 * lensExpDT;	
		  
    float truepos = 0.0f;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	if ((worldTime < 13000 || worldTime > 23000) && sunPos.z < 0) truepos = 1.0 * (timeNoon + timeSunriseSunset); 
		if ((worldTime < 23000 || worldTime > 13000) && -sunPos.z < 0) truepos = 1.0 * timeMidnight;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
	 //color.rgb += lens(texcoord.st-0.5f,sunPos.xy/100,0.1f,0.15) * sunvisibility * truepos * timeDay * (1.0 - dynamicWeather())* (1.0-isEyeInWater);
	 
	 float a = atan(texcoord.y-lightPos.y, texcoord.x-lightPos.x);
     float Sunrays_lit = max(pow(max(Circulardist(1.0,0.75f,1.0f)/1.0,0.025f),1.0)-0.75,0.0)*abs(sin(a*50.+cos(a*20.)))/5.*(abs(sin(a*50.)))/5.; 
	 color.rgb += (Sunrays_lit*truepos) * sunvisibility * vec3(1.1,0.95,0.85) * (1.0-isEyeInWater) * (1.0-timeMidnight) * 0.075f * (1.0 - dynamicWeather());
	 //float visibility = max(pow(max(1.0 - smoothCircleDist(1.0)/0.6,0.1),0.75)-0.1,0.0);
	 //color.rgb += (GetLenstex(texcoord.st)*visibility*truepos) * sunvisibility * vec3(1.1,0.95,0.85) * (1.0-isEyeInWater) * 0.002f * (1.0-timeMidnight*0.85) * (1.0 - dynamicWeather());
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	 
	gl_FragData[0] = color;
}