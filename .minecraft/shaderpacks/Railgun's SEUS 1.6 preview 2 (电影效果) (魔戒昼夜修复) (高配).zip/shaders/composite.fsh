#version 120

/*
 _______ _________ _______  _______  _ 
(  ____ \\__   __/(  ___  )(  ____ )( )
| (    \/   ) (   | (   ) || (    )|| |
| (_____    | |   | |   | || (____)|| |
(_____  )   | |   | |   | ||  _____)| |
      ) |   | |   | |   | || (      (_)
/\____) |   | |   | (___) || )       _ 
\_______)   )_(   (_______)|/       (_)

Do not modify this code until you have read the LICENSE.txt contained in the root directory of this shaderpack!

*/

/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////ADJUSTABLE VARIABLES//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define SHADOW_MAP_BIAS 0.90

#define ENABLE_SOFT_SHADOWS

/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////INTERNAL VARIABLES////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Do not change the name of these variables or their type. The Shaders Mod reads these lines and determines values to send to the inner-workings
//of the shaders mod. The shaders mod only reads these lines and doesn't actually know the real value assigned to these variables in GLSL.
//Some of these variables are critical for proper operation. Change at your own risk.

const int 		shadowMapResolution 	= 2048;
const float 	shadowDistance 			= 40.0f;
const float 	shadowIntervalSize 		= 0.4f;
const bool 		shadowHardwareFiltering0 = true;

const bool 		shadowtex1Mipmap = true;
const bool 		shadowtex1Nearest = true;
const bool 		shadowcolor0Mipmap = true;
const bool 		shadowcolor0Nearest = false;
const bool 		shadowcolor1Mipmap = true;
const bool 		shadowcolor1Nearest = false;

const int 		R8 						= 0;
const int 		RG8 					= 0;
const int 		RGB8 					= 1;
const int 		RGB16 					= 2;
const int 		gcolorFormat 			= RGB16;
const int 		gdepthFormat 			= RGB8;
const int 		gnormalFormat 			= RGB16;
const int 		compositeFormat 		= RGB8;

const float 	eyeBrightnessHalflife 	= 10.0f;
const float 	centerDepthHalflife 	= 2.0f;
const float 	wetnessHalflife 		= 100.0f;
const float 	drynessHalflife 		= 40.0f;

const int 		superSamplingLevel 		= 0;

const float		sunPathRotation 		= -40.0f;
const float 	ambientOcclusionLevel 	= 0.5f;

const int 		noiseTextureResolution  = 64;


//END OF INTERNAL VARIABLES//

/* DRAWBUFFERS:45 */

uniform sampler2D gnormal;
uniform sampler2D gdepthtex;
uniform sampler2D gdepth;
uniform sampler2D shadowcolor1;
uniform sampler2D shadowcolor;
uniform sampler2D shadowtex1;
uniform sampler2D noisetex;
uniform sampler2D depthtex1;
uniform sampler2DShadow shadow;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferProjection;

varying vec4 texcoord;
varying vec3 lightVector;
uniform vec3 sunPosition;

varying float timeSunriseSunset;
varying float timeNoon;
varying float timeMidnight;
varying float timeSkyDark;

varying vec3 colorSunlight;
varying vec3 colorSkylight;
varying vec3 colorSunglow;
varying vec3 colorBouncedSunlight;
varying vec3 colorScatteredSunlight;
varying vec3 colorTorchlight;
varying vec3 colorWaterMurk;
varying vec3 colorWaterBlue;
varying vec3 colorSkyTint;
																																																																																																																									#define K1J5 )
uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float wetness;
uniform float aspectRatio;
uniform float frameTimeCounter;
uniform float sunAngle;
uniform vec3 skyColor;
uniform vec3 cameraPosition;

/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////FUNCTIONS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
																																																																																																																														#define RW32 vec3
vec3  	GetNormals(in vec2 coord) {				//Function that retrieves the screen space surface normals. Used for lighting calculations
	return texture2DLod(gnormal, coord.st, 0).rgb * 2.0f - 1.0f;
}

float 	GetDepth(in vec2 coord) {
	return texture2D(gdepthtex, coord.st).x;
}

vec4  	GetScreenSpacePosition(in vec2 coord) {	//Function that calculates the screen-space position of the objects in the scene using the depth texture and the texture coordinates of the full-screen quad
	float depth = GetDepth(coord);
	vec4 fragposition = gbufferProjectionInverse * vec4(coord.s * 2.0f - 1.0f, coord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
		 fragposition /= fragposition.w;
																																																																																																																																	#define UBWG texture2DLod
	return fragposition;
}

vec4  	GetScreenSpacePosition(in vec2 coord, in float depth) {	//Function that calculates the screen-space position of the objects in the scene using the depth texture and the texture coordinates of the full-screen quad
		 
	vec4 fragposition = gbufferProjectionInverse * vec4(coord.s * 2.0f - 1.0f, coord.t * 2.0f - 1.0f, 2.0f * depth - 1.0f, 1.0f);
		 fragposition /= fragposition.w;

	return fragposition;
}

vec3 	CalculateNoisePattern1(vec2 offset, float size) {
	vec2 coord = texcoord.st;
																																																																																																																																																									#define U73B shadowcolor1
	coord *= vec2(viewWidth, viewHeight);
	coord = mod(coord + offset, vec2(size));
	coord /= noiseTextureResolution;
																																																																																																																		#define U38J (
	return texture2D(noisetex, coord).xyz;
}

float  	CalculateDitherPattern() {
	const int[4] ditherPattern = int[4] (0, 2, 1, 4);

	vec2 count = vec2(0.0f);
	     count.x = floor(mod(texcoord.s * viewWidth, 2.0f));
		 count.y = floor(mod(texcoord.t * viewHeight, 2.0f));

	int dither = ditherPattern[int(count.x) + int(count.y) * 2];

	return float(dither) / 4.0f;
}

float  	CalculateDitherPattern1() {
	const int[16] ditherPattern = int[16] (0 , 8 , 2 , 10,
									 	   12, 4 , 14, 6 ,
									 	   3 , 11, 1,  9 ,
									 	   15, 7 , 13, 5 );

	vec2 count = vec2(0.0f);
	     count.x = floor(mod(texcoord.s * viewWidth, 4.0f));
		 count.y = floor(mod(texcoord.t * viewHeight, 4.0f));

	int dither = ditherPattern[int(count.x) + int(count.y) * 4];

	return float(dither) / 16.0f;
}

float  	CalculateDitherPattern2() {
	const int[64] ditherPattern = int[64] ( 1, 49, 13, 61,  4, 52, 16, 64,
										   33, 17, 45, 29, 36, 20, 48, 32,
										    9, 57,  5, 53, 12, 60,  8, 56,
										   41, 25, 37, 21, 44, 28, 40, 24,
										    3, 51, 15, 63,  2, 50, 14, 62,
										   35, 19, 47, 31, 34, 18, 46, 30,
										   11, 59,  7, 55, 10, 58,  6, 54,
										   43, 27, 39, 23, 42, 26, 38, 22);

	vec2 count = vec2(0.0f);
	     count.x = floor(mod(texcoord.s * viewWidth, 8.0f));
		 count.y = floor(mod(texcoord.t * viewHeight, 8.0f));

	int dither = ditherPattern[int(count.x) + int(count.y) * 8];

	return float(dither) / 64.0f;
}

float 	LinearToExponentialDepth(in float linDepth)
{
	float expDepth = (far * (linDepth - near)) / (linDepth * (far - near));
	return expDepth;
}

float 	GetDepthLinear(in vec2 coord) {					//Function that retrieves the scene depth. 0 - 1, higher values meaning farther away
	return (near * far) / (texture2D(depthtex1, coord).x * (near - far) + far);
}

float 	ExpToLinearDepth(in float depth)
{
	return (near*far)/(depth*(near-far)+far);
}

float getnoise(vec2 pos) {
    return abs(fract(sin(dot(pos ,vec2(18.9898f,28.633f))) * 4378.5453f));
}

float CrepuscularRays(){
    float raydepth = 0.02f;
	
	float increment = 0.0001f;
	
	float noise = CalculateDitherPattern2();
	
	const float raylimit = 512.0f;	
	
	float Rdepth = GetDepth(texcoord.st);
	float linearDepth = ExpToLinearDepth(Rdepth);
	
    float dither = noise;
	float lightaccumulation = 0.0f;
	
	float numsteps = raylimit / increment;
	
	int count = 0;
	
	while(raydepth < raylimit)
	{
	  if(linearDepth < raydepth + dither * increment)
		{
			break;		
		}
	vec4 rayPos = GetScreenSpacePosition(texcoord.st, LinearToExponentialDepth(raydepth + dither * increment));
	     rayPos = gbufferModelViewInverse * rayPos;
		     rayPos = shadowModelView * rayPos;
			 rayPos = shadowProjection * rayPos;
			 rayPos /= rayPos.w;
			 
	   float dist = sqrt(dot(rayPos.xy, rayPos.xy));
		float distortFactor = (1.0f - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS; 
		
             rayPos.xy *= 1.0f/	distortFactor;
			 rayPos = rayPos * 0.5f + 0.5f;
			 
		float shadowSample = 0;
		
		int count = 0;	 

			  shadowSample += shadow2DLod(shadow, vec3(rayPos.st,rayPos.z + 0.0000f),4.0).x;
			  
			  count += 1;
				
			  shadowSample /= count;
		      lightaccumulation += (shadowSample * increment);
			  
			  raydepth += increment;
			  count++;
			  increment *= 2.0f;	
			  }
			  
        lightaccumulation /= numsteps;
		
     return lightaccumulation * 100000.0;	
}

float cubesmooth(float x) { return (x * x) * (3.0 - 2.0 * x); } // Applies a subtle S-shaped curve, domain [0 to 1]
vec2  cubesmooth(vec2  x) { return (x * x) * (3.0 - 2.0 * x); }
vec3  cubesmooth(vec3  x) { return (x * x) * (3.0 - 2.0 * x); }

#define cosmooth(x) (0.5 - cos((x) * PI) * 0.5) // Same concept as cubesmooth, slightly different distribution

float Get3DNoise(vec3 position) {
	vec3 whole = floor(position);
	vec3 part = cubesmooth(position - whole);
	
	const vec3 zscale = vec3(17.0, 0.5, 17.5);
	
	vec4 coord  = (whole.xyxy + part.xyxy) + (whole.z * zscale.x) + zscale.yyzz;
	     coord /= noiseTextureResolution;
	
	float Noise1 = texture2D(noisetex, coord.xy).x;
	float Noise2 = texture2D(noisetex, coord.zw).x;
	
	return mix(Noise1, Noise2, part.z);
}

float CrepuscularRays2()
{
	float rayDepth = 0.02f;
	float increment = 3.5f;

	const float rayLimit = 256.0f;

	float dither = texture2D(noisetex, texcoord.st * vec2(viewWidth / noiseTextureResolution, viewHeight / noiseTextureResolution)).r * 2.0f - 1.0f;	

	float lightAccumulation = 0.0f;

	float numSteps = rayLimit / increment;

	int count = 0;

	float Rdepth = GetDepth(texcoord.st);
	float linearDepth = ExpToLinearDepth(Rdepth);
	
	while (rayDepth < rayLimit)
	{
		if (linearDepth < rayDepth + dither * increment)
		{
			break;
		}
		vec4 rayPosition = GetScreenSpacePosition(texcoord.st, LinearToExponentialDepth(rayDepth + dither * increment));
		rayPosition = gbufferModelViewInverse * rayPosition;
		vec4 rayWorldPosition = rayPosition + vec4(cameraPosition.xyz, 0.0f);

		rayPosition = shadowModelView * rayPosition;
		rayPosition = shadowProjection * rayPosition;
		rayPosition /= rayPosition.w;

		float dist = sqrt(dot(rayPosition.xy, rayPosition.xy));
		float distortFactor = (1.0f - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS;
		rayPosition.xy *= 0.95f / distortFactor;
		rayPosition = rayPosition * 0.5f + 0.5f;

		float shadowSample = shadow2DLod(shadow, vec3(rayPosition.st, rayPosition.z + 0.0018f), 4).x;

		if (count < 1)
		{
			lightAccumulation += shadowSample;
		}
		else
		{
			lightAccumulation += shadowSample * increment;
		}
		lightAccumulation += shadowSample * Get3DNoise(rayWorldPosition.xyz * 0.5f);

		count += 1;			
	    shadowSample /= count;
		
		rayDepth += increment;
		count++;
		increment *= 1.0f;
	}

	lightAccumulation /= numSteps;

	return lightAccumulation * 2.5;
}





//Clouds
const float CLOUD_HEIGHT = 10.0;

const float UV_FREQ = 0.0035;

const float CLOUD_FILTER = 0.95;

const int PARALLAX_LAYERS = 4;


float filter(float f, float a)
{
   f = clamp(f - a, 0.0, 1.0);
   f /= (1.0 - a);    
   return f;
}

float CloudsDistribution(vec2 uv)
{
    float f = (texture2D(noisetex, uv * 2.0).r - 0.5) * 0.2;
    f += (texture2D(noisetex, uv * 4.0).r - 0.5) * 0.125;
    f += (texture2D(noisetex, uv * 8.0).r - 0.5) * 0.125 * 0.5;
    f += (texture2D(noisetex, uv * 16.0).r - 0.5) * 0.125 * 0.25;
    f += (texture2D(noisetex, uv * 32.0).r - 0.5) * 0.125 * 0.24;
    f += (texture2D(noisetex, uv * 64.0).r - 0.5) * 0.125 * 0.22;
    f += (texture2D(noisetex, uv * 128.0).r - 0.5) * 0.125 * 0.12;
    f += (texture2D(noisetex, uv * 256.0).r - 0.5) * 0.125 * 0.1;
    f += 0.5;

    return clamp(f, 0.0, 1.0);
}

vec2 getuv(in vec2 uv, float l)
{
    vec3 rd = normalize(vec3(uv, 0.75));
    vec2 _uv = vec2(rd.x / rd.z * l, rd.y / rd.z * l);
    return vec2(_uv);
}


void fakeVolumeticclouds(inout vec3 col, float freq,vec4 screenSpacePosition)
{
    vec4 skySpacePosition = gbufferModelViewInverse * screenSpacePosition;
    vec2 q = (skySpacePosition.xz / skySpacePosition.y);
	vec2 uv = -1.0 + 3.0 * q;

	float t = frameTimeCounter * 0.05;
	
    vec2 _uv = uv;
         _uv.y += t;
	     	 
    float l = 1.0;
    
    for (int i = 0; i < PARALLAX_LAYERS; ++i)
    {
        float h = CloudsDistribution(_uv * freq) * 0.5;
              h += CloudsDistribution(vec2(-t * 0.001, t * 0.0015) + _uv * freq * 1.1) * 0.35;
              h += CloudsDistribution(vec2(t * 0.001, -t * 0.0025) + _uv * freq * 1.2) * 0.15;
        
        float f = filter(h, CLOUD_FILTER);
              f -= (l - 1.0) * CLOUD_HEIGHT; // height
        
              f = clamp(f, 0.0, 1.0);

              f = pow(f, 1.5);
	
         col = mix(col,colorSunlight * 1.0f,f);
           
         l *= 1.09 - h * (0.18); 
       
        _uv = getuv(uv, l);
    	_uv.y += t;
    }
}

vec4 textureSmooth(in sampler2D tex, in vec2 coord)
{
	vec2 res = vec2(64.0f, 64.0f);

	coord *= res;
	coord += 0.5f;

	vec2 whole = floor(coord);
	vec2 part  = fract(coord);

	part.x = part.x * part.x * (3.0f - 2.0f * part.x);
	part.y = part.y * part.y * (3.0f - 2.0f * part.y);
	
	coord = whole + part;

	coord -= 0.5f;
	coord /= res;

	return texture2D(tex, coord);
}

float AlmostIdentity(in float x, in float m, in float n)
{
	if (x > m) return x;

	float a = 2.0f * n - m;
	float b = 2.0f * m - 3.0f * n;
	float t = x / m;

	return (a * t + b) * t * t + n;
}


float GetWaves(vec3 position) {
	float speed = 0.8;

	vec2 p = position.xz / 40.0f;

	p.xy -= position.y / 42.0f;

	p.x = -p.x;
   

	p.x += (frameTimeCounter / 40.0f) * speed;
	p.y -= (frameTimeCounter / 40.0f) * speed;
    
	float weight = 2.0f;
	float weights = weight;

	float allwaves = 1.0f;

	float wave = textureSmooth(noisetex, (p * vec2(2.0f, 1.2f))  + vec2(0.0f,  p.x * 2.1f) ).x; 			p /= 2.1f; 	/*p *= pow(2.0f, 1.0f);*/ 	p.y -= (frameTimeCounter / 50.0f) * speed; p.x -= (frameTimeCounter / 30.0f) * speed;
	      wave = 1.0f - AlmostIdentity(wave, 0.2f, 0.1f)*2.5;
	allwaves += wave;

	weight = 2.1f;	
	weights += weight;
		  wave = textureSmooth(noisetex, (p * vec2(2.0f, 1.4f))  + vec2(0.0f,  -p.x * 1.7f) ).x;	p /= 1.5f;/*p *= pow(2.0f, 2.0f);*/ 	p.x += (frameTimeCounter / 20.0f) * speed;
		  wave = 1.0f - AlmostIdentity(wave, 0.2f, 0.1f)*1.75;
		  wave *= weight;
	allwaves += wave;

	weight = 7.25f;	
	weights += weight;	
		  wave = abs(textureSmooth(noisetex, (p * vec2(1.0f, 0.75f))  + vec2(0.0f,  p.x * 1.1f) ).x);		p /= 1.3f; 	p.x -= (frameTimeCounter / 25.0f) * speed;
		  wave = 1.0f - AlmostIdentity(wave, 0.2f, 0.1f)*1.5;
		  wave *= weight;
	allwaves += wave;

	weight = 13.25f;	
	weights += weight;	
		  wave = abs(textureSmooth(noisetex, (p * vec2(1.0f, 0.75f))  + vec2(0.0f,  -p.x * 1.7f) ).x)*1.55;		p /= 1.9f; 	p.x += (frameTimeCounter / 155.0f) * speed;
		  wave *= weight;
	allwaves += wave;

	return allwaves * 0.05;
}

vec3 GetWavesNormal(vec3 position) {

	float WAVE_HEIGHT = 1.5;

	const float sampleDistance = 11.0f;

	position -= vec3(0.005f, 0.0f, 0.005f) * sampleDistance;

	float wavesCenter = GetWaves(position);
	float wavesLeft = GetWaves(position + vec3(0.01f * sampleDistance, 0.0f, 0.0f));
	float wavesUp   = GetWaves(position + vec3(0.0f, 0.0f, 0.01f * sampleDistance));

	vec3 wavesNormal;
		 wavesNormal.r = wavesCenter - wavesLeft;
		 wavesNormal.g = wavesCenter - wavesUp;

		 wavesNormal.r *= 30.0f * WAVE_HEIGHT / sampleDistance;
		 wavesNormal.g *= 30.0f * WAVE_HEIGHT / sampleDistance;

		 wavesNormal.b = 1.0;
		 wavesNormal.rgb = normalize(wavesNormal.rgb);

	return wavesNormal.rgb;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////MAIN//////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main() {

	vec3 noisePattern = CalculateNoisePattern1(vec2(0.0f), 4);
	vec4 screenSpacePosition = GetScreenSpacePosition(texcoord.st);
	vec4 worldSpacePosition = gbufferModelViewInverse * screenSpacePosition;
	vec4 worldLightVector = shadowModelViewInverse * vec4(0.0f, 0.0f, 1.0f, 0.0f);
	vec3 normal = GetNormals(texcoord.st);

	vec4 light = vec4(0.0);

	vec4 Rays = vec4(0.0);
	     Rays.r += CrepuscularRays();
         Rays.g += CrepuscularRays();
         Rays.b += CrepuscularRays();		 
	     Rays.rgb /= 3.;
		 
		 
	vec4 tpos = vec4(sunPosition, 1.0) * gbufferProjection;
		 tpos = vec4(tpos.xyz / tpos.w, 1.0);
	vec2 pos1 = tpos.xy / tpos.z;
	vec2 lightPos = pos1 * 0.5 + 0.5;

	float gr = 0.0;
	
	const float GrDensity         = 0.5;			
    const int GrSamples           = 10;
    const float GrAlpha  		  = 0.45;

	vec2 deltaTextCoord = vec2( texcoord.st - lightPos.xy );
	vec2 textCoord = texcoord.st;
		deltaTextCoord *= 1.0 / float(GrSamples) * GrDensity;
		
	for(int i = 0; i < GrSamples ; i++) {			
		textCoord -= deltaTextCoord;
		
		float sample = step(texture2D(gdepth, textCoord).r, 0.0005);
		gr += sample;
	}

	//light.rgb = colorSkylight * 0.0001;	
	//fakeVolumeticclouds(light.rgb,UV_FREQ,screenSpacePosition);	
	
		light.a = gr / GrSamples * GrAlpha;
		
	gl_FragData[0] = vec4(pow(light.rgb, vec3(1.0 / 2.2)), light.a);
	gl_FragData[1] = vec4(GetWavesNormal(vec3(texcoord.s * 75.0, 1.0, texcoord.t * 75.0)).xy * 0.5 + 0.5,1.0,1.0);
}