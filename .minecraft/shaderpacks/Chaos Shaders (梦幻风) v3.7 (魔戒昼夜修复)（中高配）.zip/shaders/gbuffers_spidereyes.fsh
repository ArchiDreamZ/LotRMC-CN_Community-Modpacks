#version 120

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;

uniform sampler2D texture;

void main() {	
	
	vec2 adjustedTexCoord = texcoord.st;
	vec4 albedo = texture2D(texture,adjustedTexCoord)*color;
	albedo.rgb *= 0.5;
	vec4 frag2 = vec4(normal*0.5+0.5, 1.0f);
	
/* DRAWBUFFERS:0246 */

	gl_FragData[0] = albedo;
	gl_FragData[1] = frag2;	
	gl_FragData[2] = vec4(lmcoord.t, 0.7, lmcoord.s, 1.0);
	gl_FragData[3] = vec4(0.0,0.0,0.0,1.0);
}