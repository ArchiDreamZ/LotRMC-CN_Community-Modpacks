#version 120

varying vec4 color;

void main() {
	gl_Position = ftransform();
	
	color = vec4(0.0,0.0,0.0,1.0);
}