#version 120

varying vec4 color;
varying vec2 texcoord;

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;

	color = gl_Color;

	vec4 viewVertex = gl_ModelViewMatrix * gl_Vertex;
	gl_Position = gl_ProjectionMatrix * viewVertex;
	
}
