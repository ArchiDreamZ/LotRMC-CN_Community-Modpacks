vec3 sky_m = vec3(0.2, 0.16, 0.1);
vec3 sky_d = vec3(0.15, 0.3, 0.7);
vec3 light_m = vec3(1.2, 0.6, 0.2);
vec3 light_d = vec3(1.25, 1.25, 1.25);

vec3 light_n = vec3(0.025, 0.1, 0.175);
vec3 sky_n = vec3(0.015, 0.06, 0.1);

vec3 sky_r = vec3(0.2, 0.3, 0.4);
vec3 light_r = vec3(0.2, 0.3, 0.4);