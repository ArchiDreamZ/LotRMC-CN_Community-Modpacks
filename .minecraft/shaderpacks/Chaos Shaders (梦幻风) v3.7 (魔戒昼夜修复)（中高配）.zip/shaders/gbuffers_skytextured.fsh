#version 120

varying vec4 color;
varying vec2 texcoord;

uniform sampler2D texture;

void main() {
	
/* DRAWBUFFERS:04 */

	gl_FragData[0] = texture2D(texture,texcoord.xy)*color;
	gl_FragData[1] = vec4(0.0,0.0,0.0,1.0);

}