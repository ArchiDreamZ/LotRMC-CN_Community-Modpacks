#version 120

varying vec4 color;
varying vec4 texcoord;
varying vec2 lmcoord;
varying vec3 normal;

uniform sampler2D texture;

void main() {
	vec2 adjustedTexCoord = texcoord.st;
	vec3 albedo = texture2D(texture,adjustedTexCoord).rgb*color.rgb;
	
/* DRAWBUFFERS:01 */

	gl_FragData[0] = vec4(albedo,(texture2D(texture,adjustedTexCoord).a));
	gl_FragData[1] = vec4(albedo/16.0,(texture2D(texture,adjustedTexCoord).a));
}