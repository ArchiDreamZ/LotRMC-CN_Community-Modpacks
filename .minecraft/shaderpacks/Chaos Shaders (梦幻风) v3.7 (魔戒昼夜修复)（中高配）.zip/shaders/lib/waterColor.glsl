//#define WaterV

#define WaterR 208 //[0 16 32 48 64 80 96 112 128 144 160 176 192 208 224 255]
#define WaterG 208 //[0 16 32 48 64 80 96 112 128 144 160 176 192 208 224 255]
#define WaterB 208 //[0 16 32 48 64 80 96 112 128 144 160 176 192 208 224 255]
#define WaterS 0.05 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00 2.25 2.50 2.75 3.00 3.25 3.50 3.75 4.00]
#define WaterA 0.25 //[0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define WaterF 32.0 //[4.0 8.0 16.0 32.0 64.0 128.0]
#define Water vec3(WaterR,WaterG,WaterB)/255.0


#ifdef WaterV
#define water_c vec3(0.5)
#else
#define water_c Water*Water
#endif

#define water_a WaterA
#define cmult WaterS
#define wfogrange WaterF