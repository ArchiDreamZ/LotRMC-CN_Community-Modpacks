vec4 getShadowPos(vec4 worldpos) {
vec4 shadowpos = shadowModelView * worldpos;

shadowpos = shadowProjection * shadowpos;
shadowpos /= shadowpos.w;

return shadowpos;
}

vec4 distortShadow(vec4 shadowpos, float distortFactor) {
shadowpos.xy *= 1.0f / distortFactor;
shadowpos.z = shadowpos.z*0.2;
shadowpos = shadowpos * 0.5f + 0.5f;

return shadowpos;
}