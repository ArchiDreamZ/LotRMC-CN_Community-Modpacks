#version 120

varying vec4 texcoord;

uniform float sunAngle;
int worldTime = int(24000.0 * sunAngle);

void main() {
	gl_Position = ftransform();
	
	texcoord = gl_MultiTexCoord0;
}
