#version 400 compatibility
/*
!! DO NOT REMOVE !!
This code is from Chocapic13' shaders
Read the terms of modification and sharing before changing something below please !
!! DO NOT REMOVE !!
*/

#define WAVING_LEAVES
#define WAVING_VINES
#define WAVING_GRASS
#define WAVING_WHEAT
#define WAVING_FLOWERS
#define WAVING_FIRE
#define WAVING_LAVA
#define WAVING_LILYPAD

#define GRASS 10031
#define CROPS 10059
#define TALLPLANTS_LOWER 10175
#define TALLPLANTS_UPPER 10176
#define LEAVES 10018
#define VINES 10106
#define LILYPAD 10111
#define FIRE 10051
#define LAVA 10010
#define WATER 10008
#define REFLECTIVE 10079
#define NOT_OCCLUSIVE 10030
#define DEAD_PLANT 10032
#define EMISSIVE 10089

#define SHADOW_MAP_BIAS 0.8
const float PI = 3.1415927;
out vec4 texcoord;

attribute vec4 mc_midTexCoord;
attribute vec4 mc_Entity;

uniform mat4 shadowProjectionInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float frameTimeCounter;
uniform float sunAngle;
int worldTime = int(24000.0 * sunAngle);
uniform float rainStrength;
uniform vec3 cameraPosition;
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

float pi2wt = PI * 2 * (frameTimeCounter * 24);

vec3 calcWave(in vec3 pos, in float fm, in float mm, in float ma, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5) {
    vec3 ret;
    float magnitude, d0, d1, d2, d3;
    magnitude = sin(pi2wt * fm + pos.x * 0.5 + pos.z * 0.5 + pos.y * 0.5) * mm + ma;
    d0 = sin(pi2wt * f0);
    d1 = sin(pi2wt * f1);
    d2 = sin(pi2wt * f2);
    ret.x = sin(pi2wt * f3 + d0 + d1 - pos.x + pos.z + pos.y) * magnitude;
    ret.z = sin(pi2wt * f4 + d1 + d2 + pos.x - pos.z + pos.y) * magnitude;
    ret.y = sin(pi2wt * f5 + d2 + d0 + pos.z + pos.y - pos.y) * magnitude;
    return ret;
}

vec3 calcMove(in vec3 pos, in float f0, in float f1, in float f2, in float f3, in float f4, in float f5, in vec3 amp1, in vec3 amp2) {
    vec3 move1 = calcWave(pos, 0.0027, 0.0400, 0.0400, 0.0127, 0.0089, 0.0114, 0.0063, 0.0224, 0.0015) * amp1;
    vec3 move2 = calcWave(pos + move1, 0.0348, 0.0400, 0.0400, f0, f1, f2, f3, f4, f5) * amp2;
    return move1 + move2;
}
vec3 calcWaterMove(in vec3 pos) {
    float fy = fract(pos.y + 0.001);
    if (fy > 0.002) {
        float wave = 0.05 * sin(2 * PI / 4 * frameTimeCounter + 2 * PI * 2 / 16 * pos.x + 2 * PI * 5 / 16 * pos.z) + 0.05 * sin(2 * PI / 3 * frameTimeCounter - 2 * PI * 3 / 16 * pos.x + 2 * PI * 4 / 16 * pos.z);
        return vec3(0, clamp(wave, -fy, 1.0 - fy), 0);
    } else {
        return vec3(0);
    }
}
vec4 BiasShadowProjection(in vec4 projectedShadowSpacePosition, in vec3 normal) {
    vec2 pos = abs(projectedShadowSpacePosition.xy * 1.25);
    float dist = pow(pow(pos.x, 12.) + pow(pos.y, 12.), 1.0 / 12.0);

    float distortFactor = (1.0 - SHADOW_MAP_BIAS) + dist * SHADOW_MAP_BIAS;

    projectedShadowSpacePosition.xy /= distortFactor * 0.85;

    projectedShadowSpacePosition.z /= 2.5;

    return projectedShadowSpacePosition;
}
void main() {
    vec4 position = ftransform();

    vec3 normal = normalize(gl_NormalMatrix * gl_Normal);

    gl_Position = BiasShadowProjection(position, normal);

    texcoord = gl_MultiTexCoord0;

    texcoord.z = 1.0;
    if (int(mc_Entity.x) == WATER) texcoord.z = 0.0;
}
