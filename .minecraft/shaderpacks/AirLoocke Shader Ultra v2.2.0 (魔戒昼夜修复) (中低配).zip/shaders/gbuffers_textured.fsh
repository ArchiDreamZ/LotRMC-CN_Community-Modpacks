#version 120

/*- Airloocke42’ , derived from Chocapic13 -*/

/* DRAWBUFFERS:0 */

bool SmoothCloud = true;

uniform sampler2D texture;

uniform float far;

varying vec4 color;
varying vec4 texcoord;

const int GL_LINEAR = 9729;
const int GL_EXP = 2048;

uniform int fogMode;

void main() {
	gl_FragData[0] = texture2D(texture,texcoord.xy)*color;
}